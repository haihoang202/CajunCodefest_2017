Advanced examples: special Javascript processing needed.
